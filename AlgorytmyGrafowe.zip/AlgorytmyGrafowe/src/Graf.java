import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;

public class Graf {
	private int liczbaWierzcho�k�w;
	private int liczbaKraw�dzi;
	private ArrayList<ArrayList<Integer>> lista;

	public Graf(String sciezka) {
		lista = dane(sciezka);
		liczbaWierzcho�k�w = liczbaWierzcholkow();
		liczbaKraw�dzi = liczbaKrawedzi();
	}



	private int liczbaKrawedzi() {
		int pom = 0;
		int liczbaKraw = 0;
		for (int i = 0; i < lista.size(); i++) {
			pom = lista.get(i).size() + pom;
		}

		return pom / 2;

	}

	private ArrayList<ArrayList<Integer>> dane(String sciezka) {

		ArrayList<ArrayList<Integer>> lista = new ArrayList<>();
		try {
			File f = new File(sciezka);
			Scanner sc = new Scanner(f);
			while (sc.hasNextLine()) {
				ArrayList<Integer> tempLista = new ArrayList<>();
				var s = sc.nextLine().split(";");
				for (int i = 1; i < s.length; i++) {
					tempLista.add(Integer.parseInt(s[i]));
				}
				lista.add(tempLista);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return lista;
	}

	@SuppressWarnings("unchecked")
	
	public ArrayList<Integer> sasiedzi(int nrWierzcholka) {
		if (nrWierzcholka < lista.size())
			return (ArrayList<Integer>) lista.get(nrWierzcholka).clone();
		else
			throw new IllegalArgumentException("Nieprawid�owy indeks wierzcho�ka");
	}

	public int wierzcholekZMaxStopniem() {
		int max = 0;
		int wierz = 0;
		for (int i = 0; i < lista.size(); i++) {
			if (max < lista.get(i).size()) {
				max = lista.get(i).size();
				wierz = i;
			}
		}
		return wierz;
	}

	public int ileSasiadowWZbiorze(Collection<Integer> zbior, int nrWierzcholka) {
		int liczbaSasiadow = 0;
		if (nrWierzcholka < lista.size()) {
			for (int i = 0; i < lista.get(nrWierzcholka).size(); i++) {
				if (zbior.contains(lista.get(nrWierzcholka).get(i))) {
					liczbaSasiadow++;
				}
			}
		} else {
			throw new IllegalArgumentException("Nieprawid�owy indeks wierzcho�ka");
		}
		return liczbaSasiadow;
	}

	private int liczbaWierzcholkow() {
		int liczbaWierz = 0;
		for (int i = 0; i < lista.size(); i++) {
			liczbaWierz = liczbaWierz + 1;
		}

		return liczbaWierz;
	}
	
	public boolean czyMaSasiadaWsr�d(Collection<Integer> zbior, int nrWierzcholka) {
		if (nrWierzcholka < lista.size()) {
			for (int i = 0; i < lista.get(nrWierzcholka).size(); i++) {
				if (zbior.contains(lista.get(nrWierzcholka).get(i))) {
					return true;
				}
			}
		} else
			throw new IllegalArgumentException("Nieprawid�owy indeks wierzcho�ka");
		return false;
	}

	public int ileWspolnychSasiadow(int wierz1, int wierz2, Collection<Integer> zbior) {
		ArrayList<Integer> lista1 = new ArrayList<>();
		ArrayList<Integer> lista2 = new ArrayList<>();
		int ile = 0;

		for (int x : this.sasiedzi(wierz1)) {
			if (zbior.contains(x)) {
				lista1.add(x);
			}
		}
		for (int y : this.sasiedzi(wierz2)) {
			if (zbior.contains(y)) {
				lista2.add(y);
			}
		}

		for (int i = 0; i < lista1.size(); i++) {
			for (int j = 0; j < lista2.size(); j++) {
				if (lista1.get(i).equals(lista2.get(j))) {
					ile++;
				}
			}
		}
		return ile;
	}

	public void wy�wietl() {
		System.out.println(lista);
	}

	public int stopienWierzcholka(int nrWierzcholka) {
		if (nrWierzcholka < lista.size()) {
			System.out.println(lista.get(nrWierzcholka).size());
			return lista.get(nrWierzcholka).size();
		} else
			throw new IllegalArgumentException("Nieprawid�owy indeks wierzcho�ka");

	}

	public boolean czyDominujacy(Collection<Integer> zbior) {
		for (int i = 0; i < this.liczbaWierzcho�k�w; i++) {
			if (!zbior.contains(i) && !czyMaSasiadaWsr�d(zbior, i))
				return false;
		}
		return true;

	}

	public HashSet<Integer> AlgorytmI() {
		HashSet<Integer> bia�e = new HashSet<>();
		HashSet<Integer> czarne = new HashSet<>();
		HashSet<Integer> szare = new HashSet<>();

		for (int i = 0; i < lista.size(); i++) {
			bia�e.add(i);
		}

		int maxWierzcholek = this.wierzcholekZMaxStopniem();
		czarne.add(maxWierzcholek);
		bia�e.remove(Integer.valueOf(maxWierzcholek));
		szare.addAll(this.sasiedzi(maxWierzcholek));
		bia�e.removeAll(this.sasiedzi(maxWierzcholek));

		while (!bia�e.isEmpty()) {
			int wierzcholek = 0;
			int max = 0;

			for (int x : szare) {
				if (max < this.ileSasiadowWZbiorze(bia�e, x)) {
					max = this.ileSasiadowWZbiorze(bia�e, x);
					wierzcholek = x;
				}
			}
			czarne.add(wierzcholek);
			szare.remove(Integer.valueOf(wierzcholek));

			for (int k : this.sasiedzi(wierzcholek)) {
				if (bia�e.contains(k)) {
					szare.add(k);
					bia�e.remove(k);

				}
			}
		}
		return czarne;
	}

	public HashSet<Integer> AlgorytmII() {

		HashSet<Integer> bia�e = new HashSet<>();
		HashSet<Integer> czarne = new HashSet<>();
		HashSet<Integer> szare = new HashSet<>();

		for (int i = 0; i < lista.size(); i++) {
			bia�e.add(i);
		}

		int maxWierz = this.wierzcholekZMaxStopniem();
		czarne.add(maxWierz);
		bia�e.remove(Integer.valueOf(maxWierz));
		szare.addAll(this.sasiedzi(maxWierz));
		bia�e.removeAll(this.sasiedzi(maxWierz));

		while (!bia�e.isEmpty()) {
			int maxPoj = 0;
			int wierzcholek = 0;
			int maxBialy = 0;
			int maxSzary = 0;
			int wierzSzary = 0;
			int wierzBia�y = 0;
			int suma = 0;
			int maxSuma = 0;
			int[] potencjaly = new int[this.liczbaWierzcho�k�w];

			for (int x : szare) {
				int ile = this.ileSasiadowWZbiorze(bia�e, x);
				potencjaly[x] = ile;
				if (maxPoj < ile) {
					maxPoj = ile;
					wierzcholek = x;
				}
			}

			for (int i : szare) {
				for (int j : this.sasiedzi(i)) {
					if (bia�e.contains(j)) {
						maxSzary = this.ileSasiadowWZbiorze(bia�e, i);
						maxBialy = this.ileSasiadowWZbiorze(bia�e, j);
						suma = maxSzary + maxBialy - this.ileWspolnychSasiadow(i, j, bia�e);
						if (maxSuma < suma) {

							maxSuma = suma;
							wierzSzary = i;
							wierzBia�y = j;
						}
					}
				}
			}

			if (maxSuma > maxPoj) {
				czarne.add(wierzSzary);
				czarne.add(wierzBia�y);
				szare.remove(Integer.valueOf(wierzSzary));
				bia�e.remove(Integer.valueOf(wierzBia�y));

				for (int p : this.sasiedzi(wierzSzary)) {
					if (bia�e.contains(p)) {
						szare.add(p);
						bia�e.remove(p);
					}
				}

				for (int r : this.sasiedzi(wierzBia�y)) {
					if (bia�e.contains(r)) {
						szare.add(r);
						bia�e.remove(r);
					}
				}

			} else {
				czarne.add(wierzcholek);
				szare.remove(Integer.valueOf(wierzcholek));

				for (int k : this.sasiedzi(wierzcholek)) {

					if (bia�e.contains(k)) {
						szare.add(k);
						bia�e.remove(k);
					}
				}
			}

		}
		return czarne;
	}

	public boolean czySp�jnyPodgrafIndukowany(Collection<Integer> zbior) {
		ArrayDeque<Integer> kolejka = new ArrayDeque<>();
		HashSet<Integer> odwiedzone = new HashSet<>();

		int s = zbior.iterator().next();

		kolejka.add(s);
		odwiedzone.add(s);
		while (!kolejka.isEmpty()) {
			int v = kolejka.remove();
			for (int i = 0; i < lista.get(v).size(); i++) {
				int w = lista.get(v).get(i);
				if (zbior.contains(w)) {

					if (!odwiedzone.contains(w)) {
						kolejka.add(w);
						odwiedzone.add(w);
					}
				}
			}
		}
		if (!(zbior.size() == odwiedzone.size())) {
			return false;

		}
		return true;

	}



}