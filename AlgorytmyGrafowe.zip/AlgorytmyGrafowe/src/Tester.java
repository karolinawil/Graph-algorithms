
import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;



public class Tester {

	    public static void main(String[] args) {
	    	
        Graf graf= new Graf("plikiTekstowe/graf5.txt");
  
       
	    System.out.println("sp�jny zbi�r dominuj�cy ALGORYTM I" + graf.AlgorytmI());      
	    System.out.println("sp�jny zbi�r dominuj�cy ALGORYTM II" + graf.AlgorytmII()); 
	    
	    System.out.println();
	    
	    System.out.println("ALGORYTM I");
	    System.out.println("-----------------------------------------------");
	    System.out.println("Podzbi�r wyznaczony wed�ug zasad dzia�ania Algorytmu I jest dominuj�cy: " + graf.czyDominujacy(graf.AlgorytmI()));
	    System.out.println("Podzbi�r wyznaczony wed�ug zasad dzia�ania Algorytmu I jest sp�jny: "+ graf.czySp�jnyPodgrafIndukowany(graf.AlgorytmI()));
	    
	    System.out.println();
	    
	    System.out.println("ALGORYTM II");
	    System.out.println("-----------------------------------------------");   
	    System.out.println("Podzbi�r wyznaczony wed�ug zasad dzia�ania Algorytmu II jest dominuj�cy: " + graf.czyDominujacy(graf.AlgorytmII()));   
	    System.out.println("Podzbi�r wyznaczony wed�ug zasad dzia�ania Algorytmu II jest sp�jny: "+ graf.czySp�jnyPodgrafIndukowany(graf.AlgorytmII()));
	    
		    }
	}



